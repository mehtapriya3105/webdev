import { useState } from "react";
import { Button, Col, Form, Row, Nav } from "react-bootstrap";
import { MdDoNotDisturbAlt, MdMoreVert } from "react-icons/md";
import { useNavigate, useParams } from "react-router-dom";
import QuestionEditor from "./QuestionEditor"; // Keep the TinyMCE editor

export default function QuizEditor() {
    const navigate = useNavigate();
    const { cid } = useParams();
    const [activeTab, setActiveTab] = useState<'Details' | 'Questions'>('Details');
    const [quizTitle, setQuizTitle] = useState<string>("Unnamed Quiz");
    const [description, setDescription] = useState<string>("Hello"); // Keep your description state
    const [points, setPoints] = useState<number>(0);
    const [published, setPublished] = useState<boolean>(false);
    const [quizType, setQuizType] = useState<string>("Graded Quiz");
    const [assignmentGroup, setAssignmentGroup] = useState<string>("ASSIGNMENTS");
    const [shuffleAnswers, setShuffleAnswers] = useState<boolean>(false);
    const [timeLimit, setTimeLimit] = useState<boolean>(false);
    const [timeLimitMinutes, setTimeLimitMinutes] = useState<number>(0);
    const [multipleAttempts, setMultipleAttempts] = useState<boolean>(false);

    // Keep your editor change handler
    const handleEditorChange = (content: string) => {
        setDescription(content);
        console.log('Description was updated:', content);
    };

    return (
        <div id="wd-quiz-editor" className="container-fluid">
            {/* Header with Points and Published Status */}
            <div className="d-flex justify-content-end align-items-center mb-3 mt-3">
                <span className="me-3">Points {points}</span>
                <div className="d-flex align-items-center me-3">
                    <MdDoNotDisturbAlt className="me-1" />
                    <span>{published ? "Published" : "Not Published"}</span>
                </div>
                <Button variant="light" className="border-0">
                    <MdMoreVert />
                </Button>
            </div>

            {/* Navigation Tabs */}
            <Nav variant="tabs" className="mb-3">
                <Nav.Item>
                    <Nav.Link
                        active={activeTab === 'Details'}
                        onClick={() => setActiveTab('Details')}
                    >
                        Details
                    </Nav.Link>
                </Nav.Item>
                <Nav.Item>
                    <Nav.Link
                        active={activeTab === 'Questions'}
                        onClick={() => setActiveTab('Questions')}
                    >
                        Questions
                    </Nav.Link>
                </Nav.Item>
            </Nav>

            {activeTab === 'Details' ? (
                <div className="details-tab">
                    {/* Quiz Title */}
                    <Form.Group className="mb-4">
                        <Form.Control
                            type="text"
                            value={quizTitle}
                            onChange={(e) => setQuizTitle(e.target.value)}
                            placeholder="Unnamed Quiz"
                            className="form-control-lg border-1"
                        />
                    </Form.Group>

                    {/* Quiz Instructions Editor - Keep your TinyMCE integration */}
                    <Form.Group className="mb-4">
                        <Form.Label>Quiz Instructions:</Form.Label>
                        <QuestionEditor
                            initialValue={description}
                            onEditorChange={handleEditorChange}
                        />
                    </Form.Group>

                    {/* Quiz Settings */}
                    <Row className="mb-3">
                        <Col md={6} className="text-end">
                            <Form.Label>Quiz Type</Form.Label>
                        </Col>
                        <Col md={3}>
                            <Form.Select
                                value={quizType}
                                onChange={(e) => setQuizType(e.target.value)}
                                className="mb-3"
                            >
                                <option value="Graded Quiz">Graded Quiz</option>
                                <option value="Practice Quiz">Practice Quiz</option>
                                <option value="Graded Survey">Graded Survey</option>
                                <option value="Ungraded Survey">Ungraded Survey</option>
                            </Form.Select>
                        </Col>
                    </Row>

                    <Row className="mb-3">
                        <Col md={6} className="text-end">
                            <Form.Label>Assignment Group</Form.Label>
                        </Col>
                        <Col md={3}>
                            <Form.Select
                                value={assignmentGroup}
                                onChange={(e) => setAssignmentGroup(e.target.value)}
                                className="mb-3"
                            >
                                <option value="ASSIGNMENTS">ASSIGNMENTS</option>
                                <option value="HOMEWORK">HOMEWORK</option>
                                <option value="PROJECTS">PROJECTS</option>
                                <option value="QUIZZES">QUIZZES</option>
                            </Form.Select>
                        </Col>
                    </Row>

                    {/* Options Section */}
                    <Row className="mb-3">
                        <Col md={7} className="text-end">
                            <h5>Options</h5>
                        </Col>
                        <Col md={5}>
                            {/* Empty column to align with the header */}
                        </Col>
                    </Row>
                    <Row className="mb-3">
                        <Col md={6} className="text-end">
                        </Col>
                        <Col md={6}>
                            <Form.Group className="mb-3">
                                <Form.Check
                                    type="checkbox"
                                    id="shuffle-answers"
                                    label="Shuffle Answers"
                                    checked={shuffleAnswers}
                                    onChange={(e) => setShuffleAnswers(e.target.checked)}
                                />
                            </Form.Group>

                            <Form.Group className="mb-3 d-flex align-items-center">
                                <Form.Check
                                    type="checkbox"
                                    id="time-limit"
                                    label="Time Limit"
                                    checked={timeLimit}
                                    onChange={(e) => setTimeLimit(e.target.checked)}
                                    className="me-2"
                                />

                                {timeLimit && (
                                    <div className="d-flex align-items-center">
                                        <Form.Control
                                            type="number"
                                            value={timeLimitMinutes}
                                            onChange={(e) => setTimeLimitMinutes(parseInt(e.target.value))}
                                            style={{ width: "100px" }}
                                            className="me-2"
                                        />
                                        <span>Minutes</span>
                                    </div>
                                )}
                            </Form.Group>

                            <div className="border p-3 mb-4">
                                <Form.Check
                                    type="checkbox"
                                    id="multiple-attempts"
                                    label="Allow Multiple Attempts"
                                    checked={multipleAttempts}
                                    onChange={(e) => setMultipleAttempts(e.target.checked)}
                                />
                            </div>
                        </Col>
                    </Row>

                    {/* Save/Cancel Buttons */}
                    <Row className="mb-3">
                        <Col md={4}>
                        </Col>
                        <Col md={4}>
                            <div className="d-flex justify-content-end mt-4">
                                <Button
                                    variant="light"
                                    className="me-2"
                                    onClick={() => navigate(`/Kambaz/Courses/${cid}/Quizzes`)}
                                >
                                    Cancel
                                </Button>
                                <Button variant="danger">
                                    Save
                                </Button>
                            </div>
                        </Col>
                        <Col md={4}>
                            {/* Empty column to align with the header */}
                        </Col>
                    </Row>
                </div>
            ) : (
                <div className="questions-tab">
                    {/* Questions Tab Content */}
                    <Row>
                        <Col>
                            <Form.Group className="mb-3">
                                <Form.Control
                                    type="text"
                                    placeholder="Question Title"
                                    className="mb-2"
                                />

                                <div className="d-flex justify-content-between mb-3">
                                    <Form.Select style={{ width: '60%' }}>
                                        <option>True/False</option>
                                        <option>Multiple Choice</option>
                                        <option>Essay</option>
                                        <option>Fill in the Blank</option>
                                    </Form.Select>

                                    <div className="d-flex align-items-center">
                                        <span className="me-2">pts:</span>
                                        <Form.Control
                                            type="number"
                                            defaultValue={3}
                                            style={{ width: '60px' }}
                                        />
                                    </div>
                                </div>

                                <p>Enter your question text, then select if True or False is the correct answer.</p>

                                <h5>Question:</h5>
                                <QuestionEditor
                                    initialValue="Is is true that 2 + 2 = 4?"
                                    onEditorChange={(content) => console.log('Question updated:', content)}
                                />

                                <div className="mt-3">
                                    {/* True/False options would go here */}
                                </div>
                            </Form.Group>
                        </Col>
                    </Row>
                </div>
            )}
        </div>
    );
}